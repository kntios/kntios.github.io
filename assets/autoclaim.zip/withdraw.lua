local lfs = require("lfs")
function filewrite(path, content)
    local file = io.open(path, "w")
    if file then
        file:write(content)
        file:close()
    end
end
function fileread(path)
    local file = io.open(path, "r")
    if file then
        local content = file:read("*l")
        file:close()
        return content;
    end
    return ""
end
math.randomseed(os.time() + tonumber(tostring(os.clock()):reverse():sub(1,6)))
-- Đọc chỉ số bắt đầu từ file start.txt (nếu có)
local version = "v2.bababa33"
local filestartpath = "/private/var/mobile/Library/AutoTouch/Scripts/startwithdraw.txt"
local fileroompath = "/private/var/mobile/Library/AutoTouch/Scripts/phong.txt"
local urlLive = "https://lite.tiktok.com/t/ZShJrvhWV/"
local readStartIndex = fileread(filestartpath)
local readRoomx = fileread(fileroompath)
local readRoom = "";
local startIndex = 1
local num = tonumber(readStartIndex)
if num and num >= 1 then
    startIndex = num
end
if readRoomx then
    readRoom = readRoomx
end
local label = {type=CONTROLLER_TYPE.LABEL, text="Auto withdraw "..version}
local label2 = {type=CONTROLLER_TYPE.LABEL, text=" "}
local label3 = {type=CONTROLLER_TYPE.LABEL, text="______________________"}
local room = {type=CONTROLLER_TYPE.INPUT, title="Room:", key="room", value=readRoom}
local startAt = {type=CONTROLLER_TYPE.INPUT, title="Start at:", key="startAt", value=startIndex}
local remember = {type=CONTROLLER_TYPE.REMEMBER, on=false}

local btn1 = {type=CONTROLLER_TYPE.BUTTON, title="START", color=0x4542f5, width=1.0, flag=1, collectInputs=true}
local btn2 = {type=CONTROLLER_TYPE.BUTTON, title="WITHDRAW THIS SESSION", color=0xcc3399, width=1.0, flag=2, collectInputs=true}
local btn3 = {type=CONTROLLER_TYPE.BUTTON, title="CLOSE", color=0xab8e00, width=1, flag=3, collectInputs=true}

local btn4 = {type=CONTROLLER_TYPE.BUTTON, title="Clear Debug", color=0xab8e00, width=1, flag=4, collectInputs=true}
local btn5 = {type=CONTROLLER_TYPE.BUTTON, title="START AT ".. (startIndex + 1), color=0xff0000, width=1.0, flag=5, collectInputs=true}
local controls = {label, room, startAt, btn1, btn2, btn5, btn3, btn4}

local orientations = { ORIENTATION_TYPE.PORTRAIT, ORIENTATION_TYPE.LANDSCAPE_LEFT, ORIENTATION_TYPE.LANDSCAPE_RIGHT };

result_dialog = dialog(controls, orientations);
readRoom = room.value
filewrite(fileroompath, room.value)
filewrite(filestartpath, startAt.value)

if (result_dialog == 4) then
    execute("rm -r /private/var/mobile/Library/AutoTouch/Scripts/Debug/*");
    stop();
else
    if (result_dialog == 3) then
        stop();
    end
end
startIndex =  tonumber(startAt.value)
if (result_dialog == 5) then
    startIndex =  tonumber(startAt.value) + 1
end
if readRoom == "" then
    alert("Chua dien phong")
    stop()
end
local path = "/private/var/mobile/Library/Preferences/iFakePro/sessions"
local fileList = {}
local function traverse(dir)
    for file in lfs.dir(dir) do
        if file ~= "." and file ~= ".." then
            local fullPath = dir .. "/" .. file
            local attr = lfs.attributes(fullPath)
            if attr then
                if attr.mode == "directory" then
                    table.insert(fileList, file)
                end
            else
                print("Failed to get attributes for: " .. fullPath)
            end
        end
    end
end
function findimg(img, wait, exact)
    exact = exact or 0.97
    timenow2 = os.time();	
	local i = wait;
    repeat
        toast("Wait "..i, 1);
		i = i-1;
        local result1 = findImage(img, 0, exact, nil, true)
        for i, v in pairs(result1) do
            return true
        end        
        usleep(1000000);
    until (os.difftime(os.time(), timenow2) > wait)
	return false
end
function findimg2(img, img2, wait, exact)
    exact = exact or 0.97
    timenow2 = os.time();	
	local i = wait;
    repeat
        toast("Wait "..i, 1);
		i = i-1;
        local result1 = findImage(img, 0, exact, nil, true)
        for i, v in pairs(result1) do
            return true
        end     
        local result2 = findImage(img2, 0, exact, nil, true)
        for i, v in pairs(result2) do
            return true
        end   
        usleep(1000000);
    until (os.difftime(os.time(), timenow2) > wait)
	return false
end
function findimgandclick(img, wait, exact)
    exact = exact or 0.96
    timenow2 = os.time();	
	local i = wait;
    repeat
        toast("Wait "..i, 1);
		i = i-1;
        local result1 = findImage(img, 0, exact, nil, true)
        for i, v in pairs(result1) do
			local x = v[1]; y = v[2];
			touchDown(4, x, y);
			usleep(97942.79);
			touchUp(4, x, y);
			usleep(1000000);
            return true
        end        
        usleep(1000000);
    until (os.difftime(os.time(), timenow2) > wait)
	return false
end
function findimg2andclick(img, img2, wait)
    timenow2 = os.time();	
	local i = wait;
    repeat
        toast("Wait "..i, 1);
		i = i-1;
        local result1 = findImage(img, 0, 0.96, nil, true)
        local result2 = findImage(img2, 0, 0.96, nil, true)
        for i, v in pairs(result1) do
			local x = v[1]; y = v[2];
			touchDown(4, x, y);
			usleep(97942.79);
			touchUp(4, x, y);
			usleep(1000000);
            return true
        end    
        for i, v in pairs(result2) do
			local x = v[1]; y = v[2];
			touchDown(4, x, y);
			usleep(97942.79);
			touchUp(4, x, y);
			usleep(1000000);
            return true
        end       
        usleep(1000000);
    until (os.difftime(os.time(), timenow2) > wait)
	return false
end
function findimgsandclick(imgs, wait)
    local timenow2 = os.time()
    local i = wait
    repeat
        toast("Wait " .. i, 1)
        i = i - 1
        for _, img in ipairs(imgs) do
            local result = findImage(img, 0, 0.96, nil, true)
            for _, v in pairs(result) do
                local x = v[1]
                local y = v[2]
                touchDown(4, x, y)
                usleep(97942.79)
                touchUp(4, x, y)
                usleep(1000000)
                return true
            end
        end
        usleep(1000000)
    until (os.difftime(os.time(), timenow2) > wait)
    return false
end
function findimgswpieandclick(img, wait, exact)
    exact = exact or 0.96
    timenow2 = os.time();	
	local i = wait;
    repeat
        toast("Wait "..i, 1);
		i = i-1;
        local result1 = findImage(img, 0, exact, nil, true)
        for i, v in pairs(result1) do
			local x = v[1]; y = v[2];
			touchDown(4, x, y);
			usleep(97942.79);
			touchUp(4, x, y);
			usleep(1000000);
            return true
        end
        touchDown(3, 400, 700);
        usleep(16622);
        touchMove(3, 400, 680);
        usleep(16622);
        touchMove(3, 400, 660);
        usleep(16622);
        touchMove(3, 400, 640);
        usleep(16622);
        touchUp(3, 400, 640);
        usleep(3000000);
    until (i <= 0)
	return false
end
function findimgswpie(img, wait, exact)
    exact = exact or 0.96
    timenow2 = os.time();	
	local i = wait;
    repeat
        toast("Wait "..i, 1);
		i = i-1;
        local result1 = findImage(img, 0, exact, nil, true)
        for i, v in pairs(result1) do
            return true
        end
        touchDown(3, 400, 700);
        usleep(16622);
        touchMove(3, 400, 680);
        usleep(16622);
        touchMove(3, 400, 660);
        usleep(16622);
        touchMove(3, 400, 640);
        usleep(16622);
        touchUp(3, 400, 640);
        usleep(3000000);
    until (i <= 0)
	return false
end
function swipeTopUp()
    local startX = 1200
    local startY = 400
    local step = 100
    local delay = 20000
    for i = 1, 5 do            
        touchDown(1, startX, startY)
        usleep(delay)   
        for j = 1, 6 do     
            touchMove(1, startX, startY + step * j)        
            usleep(delay)
        end        
        touchUp(1, startX, startY + step * 6)
        usleep(500000)
    end
end
function swipeTopDown()
    local startX = 1200
    local startY = 400 
    local step = 100
    local delay = 20000

    for i = 1, 5 do            
        touchDown(1, startX, startY)
        usleep(delay)   
        for j = 1, 6 do     
            touchMove(1, startX, startY - (step * j))
            usleep(delay)
        end        
        touchUp(1, startX, startY - (step * 6))
        usleep(500000)
    end
end
function swipeTopDown2()
    local startX = 400
    local startY = 1100 
    local step = 100
    local delay = 20000

    for i = 1, 5 do            
        touchDown(1, startX, startY)
        usleep(delay)   
        for j = 1, 6 do     
            touchMove(1, startX, startY - (step * j)) 
            usleep(delay)
        end        
        touchUp(1, startX, startY - (step * 6))
        usleep(500000)
    end
end
function randomEmail()
    local charset = "abcdefghijklmnopqrstuvwxyz0123456789"
    local function randomString(length)
        local str = ""
        for i = 1, length do
            local rand = math.random(1, #charset)
            str = str .. charset:sub(rand, rand)
        end
        return str
    end

    local username = randomString(math.random(6, 12))
    local domain = randomText()
    local dotdomain = randomDotdomain()

    return username .. "@" .. domain .. "." ..dotdomain
end
function randomText()
    local charset = "abcdefghijklmnopqrstuvwxyz"
    local function randomString(length)
        local str = ""
        for i = 1, length do
            local rand = math.random(1, #charset)
            str = str .. charset:sub(rand, rand)
        end
        return str
    end

    local text = randomString(math.random(8, 10))
    return text
end
function randomDotdomain()
    local charset = "abcdefghijklmnopqrstuvwxyz"
    local function randomString(length)
        local str = ""
        for i = 1, length do
            local rand = math.random(1, #charset)
            str = str .. charset:sub(rand, rand)
        end
        return str
    end

    local text = randomString(math.random(3, 4))
    return text
end
function sessionRutTien(index)
    toast("Withdraw #"..index,5)
    appKill("com.ss.iphone.ugc.tiktok.lite");
    appKill("com.apple.mobilesafari");
    usleep(1000000);    
    appKill("com.apple.mobilesafari");
    usleep(1000000); 
    appActivate("com.ss.iphone.ugc.tiktok.lite");
    usleep(5000000);      
    local images = {"img/bt_event.png", "img/bt_event2.png", "img/bt_event3.png"}  
    if not findimgsandclick(images, 30) then
        return false
    end   
    while 1<2 do
        if not findimgandclick("img/bt_retry.png", 20) then
            break;
        end
    end
    if findimgandclick("img/bt_ok.png", 15) then
        usleep(10000000)
    end
    swipeTopUp()    
    if findimg2andclick("img/bt_paypay.png", "img/bt_paypay2.png", 60) then
        usleep(5000000)
        if findimgswpie("img/check_giftee_menu.png", 30) then
            usleep(2000000)
            if findimgandclick("img/bt_gifteepay.png", 60) then
                usleep(10000000)
                if not findimg("img/check_gifteepay.png",10) then
                    toast("Da rut du trong ngay",5)
                    return
                end
                if findimg("img/bt_not_enough_points.png", 5) then
                    toast("Khong du point",5)
                    return
                else
                    usleep(10000000)
                    local startTime = os.time()
                    while 1<2 do
                        touchDown(3, 157.04, 1025.70);
                        usleep(132511.67);
                        touchUp(3, 157.04, 1025.70);
                        usleep(1000000)
                        if findimg("img/check_100Yselected.png", 2) then
                            break;
                        end
                        if os.difftime(os.time(), startTime) > 10 then
                            alert("Loi: khong click duoc o 100Y")
                            stop()
                        end
                        usleep(2000000)
                    end                
                    usleep(2000000)
                    if findimgandclick("img/bt_withdraw.png", 5) then
                        if findimgandclick("img/bt_withdraw.png", 2) then
                            findimgandclick("img/bt_withdraw.png", 2)
                        end
                        if findimgandclick("img/bt_withdraw_confirm.png", 5) then   
                            if findimgandclick("img/bt_withdraw_confirm.png", 2) then  
                                findimgandclick("img/bt_withdraw_confirm.png", 2)
                            end                     
                            usleep(1000000)
                            if findimg("img/check_withdraw_success.png", 20, 0.99) then
                                usleep(1000000)
                                swipeTopDown()
                                usleep(1000000)
                                if findimgandclick("img/bt_checkcard.png", 5) then
                                    if findimgandclick("img/bt_checkcard.png", 2) then
                                        findimgandclick("img/bt_checkcard.png", 2)
                                    end
                                    usleep(5000000)
                                    saveGift(index)
                                else
                                    alert("Loi: khong tim thay nut check card")
                                    stop()
                                end
                            else
                                alert("Loi: khong tim thay thong bao thanh cong")
                                stop()
                            end
                        else
                            if findimg("img/check_withdraw_success.png", 20, 0.99) then
                                usleep(1000000)
                                swipeTopDown()
                                usleep(1000000)
                                if findimgandclick("img/bt_checkcard.png", 5) then
                                    if findimgandclick("img/bt_checkcard.png", 2) then
                                        findimgandclick("img/bt_checkcard.png", 2)
                                    end
                                    usleep(5000000)
                                    saveGift(index)
                                else
                                    alert("Loi: khong tim thay nut check card")
                                    stop()
                                end
                            else
                                alert("Loi: khong tim thay nut confirm")
                                stop()
                            end
                        end
                    else
                        usleep(1000000)
                        swipeTopDown()
                        findimgandclick("img/bt_hidekeyboard.png", 1)                
                        if findimgandclick("img/text_email.png", 3, 0.999) then
                            copyText(randomEmail());
                            usleep(100000)
                            findimgandclick("img/text_email.png", 3, 0.999)
                            if findimg2andclick("img/bt_paste.png", "img/bt_paste2.png", 5, 0.98) then
                                usleep(500000)
                                if not findimgandclick("img/bt_hidekeyboard.png", 3, 0.96) then
                                    touchDown(5, 436.21, 211.21);
                                    usleep(147529.58);
                                    touchUp(5, 436.21, 211.21);
                                end
                                if findimgandclick("img/text_fname.png", 3, 0.999) then      
                                    toast("Dien first name",2)                      
                                    copyText(randomText())
                                    usleep(500000)
                                    while 1<2 do
                                        findimgandclick("img/text_fname.png", 3, 0.999)                                        
                                        findimg2andclick("img/bt_paste.png", "img/bt_paste2.png", 5, 0.98)  
                                        if not findimg("img/text_fname.png", 3, 0.9999) then
                                            break;
                                        end
                                        usleep(1000000)        
                                    end                                                                        
                                    findimgandclick("img/bt_hidekeyboard.png", 3, 0.96)
                                    usleep(2000000)
                                    findimgandclick("img/text_lname3.png", 3, 0.999)   
                                    toast("Dien last name",2)   
                                    copyText(randomText())
                                    usleep(500000);                                    
                                    while 1<2 do
                                        findimgandclick("img/text_lname3.png", 3, 0.999)                                        
                                        findimg2andclick("img/bt_paste.png", "img/bt_paste2.png", 5, 0.98)    
                                        if not findimg("img/text_lname3.png", 3, 0.9999) then
                                            break;
                                        end
                                        usleep(1000000)        
                                    end     
                                    findimgandclick("img/bt_hidekeyboard.png", 3, 0.96)   
                                    toast("Doi diem",2)   
                                    usleep(500000);
                                    if not findimgandclick("img/bt_withdraw.png", 5) then
                                        alert("Loi: khong tim thay nut doi diem")
                                        stop();
                                    end
                                    if findimgandclick("img/bt_withdraw_confirm.png", 5) then
                                        if findimgandclick("img/bt_withdraw_confirm.png", 2) then  
                                            findimgandclick("img/bt_withdraw_confirm.png", 2)
                                        end
                                        usleep(1000000)
                                        if findimg("img/check_withdraw_success.png", 20, 0.99) then
                                            usleep(1000000)
                                            swipeTopDown()
                                            usleep(1000000)
                                            if findimgandclick("img/bt_checkcard.png", 5) then
                                                if findimgandclick("img/bt_checkcard.png", 2) then
                                                    findimgandclick("img/bt_checkcard.png", 2)
                                                end
                                                usleep(5000000)
                                                saveGift(index)
                                            else
                                                alert("Loi: khong tim thay nut check card")
                                                stop()
                                            end
                                        else
                                            alert("Loi: khong tim thay thong bao thanh cong")
                                            stop()
                                        end
                                    else
                                        if findimg("img/check_withdraw_success.png", 20, 0.99) then
                                            usleep(1000000)
                                            swipeTopDown()
                                            usleep(1000000)
                                            if findimgandclick("img/bt_checkcard.png", 5) then
                                                if findimgandclick("img/bt_checkcard.png", 2) then
                                                    findimgandclick("img/bt_checkcard.png", 2)
                                                end
                                                usleep(5000000)
                                                saveGift(index)
                                            else
                                                alert("Loi: khong tim thay nut check card")
                                                stop()
                                            end
                                        else
                                            alert("Loi: khong tim thay nut confirm")
                                            stop()
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end
function saveGift(index)
    local folderPath = "/private/var/mobile/Documents"

    -- Ham lay danh sach file .url
    function getUrlFiles()
        local handle = io.popen("ls " .. folderPath)
        local fileList = handle:read("*a")
        handle:close()

        local files = {}
        for filename in string.gmatch(fileList, "[^\r\n]+") do
            if string.match(filename, "%.url$") then
                files[filename] = true
            end
        end
        return files
    end

    function extractUrlFromFile(file)
        local path = folderPath .. "/" .. file
        local f = io.open(path, "r")
        if f then
            for line in f:lines() do
                local url = line:match("^URL=(.+)")
                if url then
                    f:close()
                    return url
                end
            end
            f:close()
        end
        return nil
    end

    function trim(s)
        return (s:gsub("^%s*(.-)%s*$", "%1"))
    end

    local firstScan = getUrlFiles()

    -- Buoc 2: share
    findimgandclick("img/bt_safari_share.png", 20)
    usleep(1000000)
    swipeTopDown2()
    usleep(3000000)
    if findimgandclick("img/bt_save_filza.png", 5) then
        usleep(1000000)
        if not findimgandclick("img/bt_save_filza_2.png", 5) then
            alert("Loi: khong tim thay nut save filza")
            stop()
        end
    else
        appKill("com.apple.mobilesafari");
        usleep(5000000)
        appRun("com.apple.mobilesafari");
        usleep(10000000)
        if not findimgandclick("img/bt_urlbar.png", 5) then
            alert("Loi: khong tim thay link giftee")
            stop()
        end
        if not findimgandclick("img/bt_urlbar_select.png", 5) then
            alert("Loi: khong tim thay link giftee")
            stop()
        end
        if not findimg2andclick("img/bt_copy.png", "img/bt_copy2.png", 5) then
            alert("Loi: khong tim thay nut copy URL")
            stop()
        end

        local cliptext = clipText()
        if cliptext and string.find(cliptext, "giftee%.biz") then
            local url = cliptext
            toast(url)
            local serial = getSN()
            local saveURL = "https://music9.online/upnotes.php?user=" .. serial .. "&team=" .. string.lower(readRoom) .. "&data=" .. trim(url)
            toast(saveURL, 10)
            usleep(1000000)
            openURL(saveURL)
            usleep(1000000)
            if findimg("img/check_upnotesok.png", 90) then
                toast("Success #" .. index, 10)
                return
            else
                openURL(saveURL)
                usleep(1000000)
                if findimg("img/check_upnotesok.png", 90) then
                    toast("Success #" .. index, 10)
                else
                    alert("Loi: Up du lieu len note")
                    stop()
                end
            end
        else
            alert("Loi: URL giftee khong hop le")
            stop()
        end
    end   

    -- Buoc 3: Duyet lai lan 2
    local secondScan = getUrlFiles()

    -- Buoc 4: So sanh va lay file moi
    for filename, _ in pairs(secondScan) do
        if not firstScan[filename] then
            local url = extractUrlFromFile(filename)
            if url then
                toast(url)
                local serial = getSN()
                local saveURL = "https://music9.online/upnotes.php?user=" .. serial .. "&team=" .. string.lower(readRoom) .. "&data=" .. trim(url)
                toast(saveURL, 10)
                usleep(1000000)
                openURL(saveURL)
                if findimg("img/check_upnotesok.png", 60) then
                    toast("Success #" .. index, 10)
                    return
                else
                    alert("Loi: Up du lieu len note")
                    stop()
                end
            end
        end
    end    
end
function autoClaim()
    appKill("com.ss.iphone.ugc.tiktok.lite");
    appKill("com.apple.mobilesafari");
    if startIndex > #fileList then
        alert("KHONG DU SESSION " .. startIndex);
    else
        for i = startIndex, #fileList do
            execute("rm -r /private/var/mobile/Library/AutoTouch/Scripts/Debug/*");
            appKill("com.ss.iphone.ugc.tiktok.lite");
            appKill("com.apple.mobilesafari");
            filewrite(filestartpath, tostring(i))
            appActivate("ifakepro.settings");
            if findimg("img/check_restoredone.png", 10) then
                toast("Online", 2)
            else
                touchDown(3, 0.00, 1023.99);
                usleep(2344.33);
                touchUp(3, 0.00, 1023.99);
                usleep(271047.29);
                touchDown(6, 630.20, 1207.96);
                usleep(99876.92);
                touchUp(6, 630.20, 1207.96);
                usleep(1349327.58);
                touchDown(3, 643.55, 824.12);
                usleep(132616.79);
                touchUp(3, 643.55, 824.12);
                usleep(1254895.00);
                touchDown(3, 0.00, 1109.99);
                usleep(852.25);
                touchUp(3, 0.00, 1109.99);
                usleep(212743.21);
                touchDown(1, 465.98, 413.80);
                usleep(131666.71);
                touchUp(1, 465.98, 413.80);
                usleep(3000000)
            end

            local filePath = fileList[i]
            toast("Restore #" .. i .. ": " .. filePath, 10)
            openURL("ifakepro://restore?folder=" .. filePath)
            usleep(30000000)

            local startTime = os.time()
            while 1 < 2 do
                if findimgandclick("img/check_restoredone.png", 2) then
                    toast("Restore done", 3)
                    break
                end
                if os.difftime(os.time(), startTime) > 60 then
                    toast("Het thoi gian 60 giay, dung vong lap.")
                    alert("Error restore timeout")
                    stop()
                end
                usleep(2000000)
            end

            usleep(2000000)
            appActivate("com.ss.iphone.ugc.tiktok.lite");
            usleep(3000000);
            if findimg2andclick("img/bt_dont.png", "img/bt_done.png", 20) then
                usleep(5000000);
                findimg2andclick("img/bt_dont.png", "img/bt_done.png", 10)
            end
            if findimgandclick("img/bt_event.png", 10) then
                findimgandclick("img/bt_closepopup.png", 30, 0.95)
            end
            if (result_dialog == 1) then
                sessionRutTien(i)
            end
        end
        execute("rm -r /private/var/mobile/Library/AutoTouch/Scripts/Debug/*");
        filewrite(filestartpath, "1")
        alert("DONE");
    end
end

traverse(path)

if (result_dialog == 2) then
    sessionRutTien(1)
else
    autoClaim()
end
