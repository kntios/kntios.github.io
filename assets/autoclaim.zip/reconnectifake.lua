appActivate("ifakepro.settings");
usleep(1000000);
touchDown(3, 709.24, 850.58);
usleep(133469.00);
touchUp(3, 709.24, 850.58);
usleep(1667228.67);

touchDown(2, 385.92, 422.96);
usleep(115016.33);
touchUp(2, 385.92, 422.96);