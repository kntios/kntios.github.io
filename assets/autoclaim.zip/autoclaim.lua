local lfs = require("lfs")
function filewrite(path, content)
    local file = io.open(path, "w")
    if file then
        file:write(content)
        file:close()
    end
end
function fileread(path)
    local file = io.open(path, "r")
    if file then
        local content = file:read("*l")
        file:close()
        return content;
    end
end
function ensure_dir(path)
    local attr = lfs.attributes(path)
    if not attr or attr.mode ~= "directory" then
        execute("mkdir -p " .. path)
    end
end
-- Đọc chỉ số bắt đầu từ file start.txt (nếu có)
local version = "v4.6"
local filestartpath = "/private/var/mobile/Library/AutoTouch/Scripts/start.txt"
local urlLive = "snssdk473824://user/@anhlinhu0e4a/live"
local readStartIndex = fileread(filestartpath)
local startIndex = 1
local num = tonumber(readStartIndex)
if num and num >= 1 then
    startIndex = num
end
local label = {type=CONTROLLER_TYPE.LABEL, text="Auto claim "..version}
local label2 = {type=CONTROLLER_TYPE.LABEL, text=" "}
local label3 = {type=CONTROLLER_TYPE.LABEL, text="______________________"}
local startAt = {type=CONTROLLER_TYPE.INPUT, title="Start at:", key="startAt", value=startIndex}

local remember = {type=CONTROLLER_TYPE.REMEMBER, on=false}

local btn1 = {type=CONTROLLER_TYPE.BUTTON, title="START", color=0x4542f5, width=1.0, flag=1, collectInputs=true}
local btn2 = {type=CONTROLLER_TYPE.BUTTON, title="START AT 1", color=0xff0000, width=1.0, flag=2, collectInputs=false}
local btn3 = {type=CONTROLLER_TYPE.BUTTON, title="CLOSE", color=0xab8e00, width=1, flag=3, collectInputs=false}

local btn4 = {type=CONTROLLER_TYPE.BUTTON, title="Clear Debug", color=0xab8e00, width=1, flag=4, collectInputs=false}

local btn5 = {type=CONTROLLER_TYPE.BUTTON, title="START EVENT SHARE + UPLOAD", color=0xff6699, width=1.0, flag=5, collectInputs=true}
local btn6 = {type=CONTROLLER_TYPE.BUTTON, title="START EVENT LIVE + UPLOAD", color=0xff6699, width=1.0, flag=6, collectInputs=true}
local controls = {label, startAt,  btn1, btn2, label2, btn5,btn6,label2, btn3, btn4}

local orientations = { ORIENTATION_TYPE.PORTRAIT, ORIENTATION_TYPE.LANDSCAPE_LEFT, ORIENTATION_TYPE.LANDSCAPE_RIGHT };

result_dialog = dialog(controls, orientations);
if (result_dialog == 3) then
    stop();
end
if (result_dialog == 4) then
    execute("rm -r /private/var/mobile/Library/AutoTouch/Scripts/Debug/*");
    stop();
end
if (result_dialog == 1) then
    startIndex = tonumber(startAt.value);
end
if (result_dialog == 6) then
    startIndex = tonumber(startAt.value);
end
if (result_dialog == 2) then
    startIndex = 1;
end
if (result_dialog == 5) then
    startIndex = 1;
end

filewrite(filestartpath, tostring(startIndex))

local path = "/private/var/mobile/Library/Preferences/iFakePro/sessions"

local fileList = {}

local function traverse(dir)
    for file in lfs.dir(dir) do
        if file ~= "." and file ~= ".." then
            local fullPath = dir .. "/" .. file
            local attr = lfs.attributes(fullPath)
            if attr and attr.mode == "directory" then
                table.insert(fileList, {
                    name = file,
                    path = fullPath,
                    time = attr.modification  -- thời gian sửa đổi cuối cùng
                })
            end
        end
    end
end

function findimg(img, wait, exact)
    exact = exact or 0.97
    timenow2 = os.time();	
	local i = wait;
    repeat
        toast("Wait "..i, 1);
		i = i-1;
        local result1 = findImage(img, 0, exact, nil, true)
        for i, v in pairs(result1) do
            return true
        end        
        usleep(1000000);
    until (os.difftime(os.time(), timenow2) > wait)
	return false
end
function findimg2(img, img2, wait, exact)
    exact = exact or 0.97
    timenow2 = os.time();	
	local i = wait;
    repeat
        toast("Wait "..i, 1);
		i = i-1;
        local result1 = findImage(img, 0, exact, nil, true)
        for i, v in pairs(result1) do
            return true
        end     
        local result2 = findImage(img2, 0, exact, nil, true)
        for i, v in pairs(result2) do
            return true
        end   
        usleep(1000000);
    until (os.difftime(os.time(), timenow2) > wait)
	return false
end
function findimgandclick(img, wait, exact)
    exact = exact or 0.96
    timenow2 = os.time();	
	local i = wait;
    repeat
        toast("Wait "..i, 1);
		i = i-1;
        local result1 = findImage(img, 0, exact, nil, true)
        for i, v in pairs(result1) do
			local x = v[1]; y = v[2];
			touchDown(4, x, y);
			usleep(97942.79);
			touchUp(4, x, y);
			usleep(1000000);
            return true
        end        
        usleep(1000000);
    until (os.difftime(os.time(), timenow2) > wait)
	return false
end
function findimg2andclick(img, img2, wait)
    timenow2 = os.time();	
	local i = wait;
    repeat
        toast("Wait "..i, 1);
		i = i-1;
        local result1 = findImage(img, 0, 0.96, nil, true)
        local result2 = findImage(img2, 0, 0.96, nil, true)
        for i, v in pairs(result1) do
			local x = v[1]; y = v[2];
			touchDown(4, x, y);
			usleep(97942.79);
			touchUp(4, x, y);
			usleep(1000000);
            return true
        end    
        for i, v in pairs(result2) do
			local x = v[1]; y = v[2];
			touchDown(4, x, y);
			usleep(97942.79);
			touchUp(4, x, y);
			usleep(1000000);
            return true
        end       
        usleep(1000000);
    until (os.difftime(os.time(), timenow2) > wait)
	return false
end
function findimgsandclick(imgs, wait)
    local timenow2 = os.time()
    local i = wait
    repeat
        toast("Wait " .. i, 1)
        i = i - 1
        for _, img in ipairs(imgs) do
            local result = findImage(img, 0, 0.96, nil, true)
            for _, v in pairs(result) do
                local x = v[1]
                local y = v[2]
                touchDown(4, x, y)
                usleep(97942.79)
                touchUp(4, x, y)
                usleep(1000000)
                return true
            end
        end
        usleep(1000000)
    until (os.difftime(os.time(), timenow2) > wait)
    return false
end
function findimgswpieandclick(img, wait, exact)
    exact = exact or 0.96
    timenow2 = os.time();	
	local i = wait;
    repeat
        toast("Wait "..i, 1);
		i = i-1;
        local result1 = findImage(img, 0, exact, nil, true)
        for i, v in pairs(result1) do
			local x = v[1]; y = v[2];
			touchDown(4, x, y);
			usleep(97942.79);
			touchUp(4, x, y);
			usleep(1000000);
            return true
        end
        touchDown(3, 400, 700);
        usleep(16622);
        touchMove(3, 400, 670);
        usleep(16622);
        touchMove(3, 400, 640);
        usleep(16622);
        touchMove(3, 400, 610);
        usleep(16622);
        touchUp(3, 400, 610);
        usleep(3000000);
    until (i <= 0)
	return false
end
function findimgsswpieandclick(imgs, wait, exact)
    exact = exact or 0.96
    timenow2 = os.time();	
	local i = wait;
    repeat
        toast("Wait "..i, 1);
		i = i-1;
        for _, img in ipairs(imgs) do
            local result1 = findImage(img, 0, exact, nil, true)
            for i, v in pairs(result1) do
                local x = v[1]; y = v[2];
                touchDown(4, x, y);
                usleep(97942.79);
                touchUp(4, x, y);
                usleep(1000000);
                return true
            end
        end
        touchDown(3, 400, 700);
        usleep(16622);
        touchMove(3, 400, 670);
        usleep(16622);
        touchMove(3, 400, 640);
        usleep(16622);
        touchMove(3, 400, 610);
        usleep(16622);
        touchUp(3, 400, 610);
        usleep(3000000);
    until (i <= 0)
	return false
end
function swipeTopUp()
    local startX = 1200
    local startY = 400
    local step = 100
    local delay = 20000
    for i = 1, 5 do            
        touchDown(1, startX, startY)
        usleep(delay)   
        for j = 1, 6 do     
            touchMove(1, startX, startY + step * j)        
            usleep(delay)
        end        
        touchUp(1, startX, startY + step * 6)
        usleep(500000)
    end
end
function sessionEventShare(index)
	toast("Event Share #"..index,5)
	appKill("com.ss.iphone.ugc.tiktok.lite");
    appKill("com.apple.mobilesafari");
    usleep(1000000);    
    appKill("com.apple.mobilesafari");
    usleep(1000000); 
    appActivate("com.ss.iphone.ugc.tiktok.lite");
    usleep(5000000);        
	local images = {"img/bt_event.png", "img/bt_event2.png", "img/bt_event3.png"}  
	if not findimgsandclick(images, 30) then
		return false
	end   
    while 1<2 do
        if not findimgandclick("img/bt_retry.png", 20) then
            break;
        end
    end
    if findimgandclick("img/bt_ok.png", 20) then
        usleep(10000000)
    end
    swipeTopUp()    
    local images_event = {"img/bt_event_share2.png", "img/bt_event_share3.png"}  
	if findimgsswpieandclick(images_event, 20) then
        usleep(2000000)
        if findimg("img/check_event_share.png", 20) then
            usleep(1000000)
            touchDown(6, 255.57, 1083.73);
            usleep(100761.42);
            touchUp(6, 255.57, 1083.73);
            usleep(3000000)
            if findimg("img/bt_share_with_p.png", 30) then
                for i = 1, 10 do            
                    findimgandclick("img/bt_share_with_p.png", 5)
                    usleep(500000)
                    findimgandclick("img/bt_copy_link.png", 5)
                    usleep(500000)
                end     
            end      
        end
	end
end
function sessionEventUpload(index)
	toast("Event Upload #"..index,5)
	appKill("com.ss.iphone.ugc.tiktok.lite");
    appKill("com.apple.mobilesafari");
    usleep(1000000);    
    appKill("com.apple.mobilesafari");
    usleep(1000000); 
    appActivate("com.ss.iphone.ugc.tiktok.lite");
    usleep(5000000);        
	local images = {"img/bt_event.png", "img/bt_event2.png", "img/bt_event3.png"}  
	if not findimgsandclick(images, 30) then
		return false
	end   
    while 1<2 do
        if not findimgandclick("img/bt_retry.png", 20) then
            break;
        end
    end
    if findimgandclick("img/bt_ok.png", 20) then
        usleep(10000000)
    end
    if findimgandclick("img/bt_close_eventpopup.png", 5, 0.95) then
        usleep(2000000)
    end
    swipeTopUp()    
    local images_event = {"img/bt_event_upload.png", "img/bt_event_upload2.png"}  
	if findimgsswpieandclick(images_event, 20) then
        local startTime = os.time()
        while 1<2 do
            execute("rm -r /private/var/mobile/Library/AutoTouch/Scripts/Debug/*");
            if os.difftime(os.time(), startTime) > 60 then
                toast("Hết thời gian 60 giây, dừng vòng lặp.")
                return false;
            end
            usleep(1000000)
            if not findimgsandclick(images_event, 2) then
                break;
            end
            touchDown(3, 400, 700);
            usleep(16622);
            touchMove(3, 400, 670);
            usleep(16622);
            touchMove(3, 400, 640);
            usleep(16622);
            touchUp(3, 400, 640);
            usleep(3000000);
        end
        if findimg("img/check_post.png", 10) then
            usleep(1000000)
            touchDown(4, 608.65, 990.08);
            usleep(116535.29);
            touchUp(4, 608.65, 990.08);
            usleep(3000000)
            if not findimg("img/bt_videos_selected.png",5) then
                findimgandclick("img/bt_videos.png", 5, 0.99)
            end
            local startTime = os.time()
            while 1<2 do
                execute("rm -r /private/var/mobile/Library/AutoTouch/Scripts/Debug/*");
                if os.difftime(os.time(), startTime) > 60 then
                    toast("Hết thời gian 60 giây, dừng vòng lặp.")
                    return false;
                end
                math.randomseed(os.time()) -- Khởi tạo seed cho random
                local x = math.random(87, 624)
                local y = math.random(370, 808)
                touchDown(4, x, y);
                usleep(116535.29);
                touchUp(4, x, y);
                if findimgandclick("img/bt_next_uploadvideo.png", 3) then
                    usleep(2000000);
                    break;
                end
            end
            local startTime = os.time()
            while 1<2 do
                execute("rm -r /private/var/mobile/Library/AutoTouch/Scripts/Debug/*");
                if os.difftime(os.time(), startTime) > 60 then
                    toast("Hết thời gian 60 giây, dừng vòng lặp.")
                    return false;
                end
                usleep(1000000);
                touchDown(1, 645.60, 1201.85);
                usleep(117264.62);
                touchUp(1, 645.60, 1201.85);
                if findimgandclick("img/bt_postvideo.png", 10) then
                    break;
                end
            end    
            findimgandclick("img/bt_postnow.png", 10)
            usleep(40000000);
        else
            toast("Error event_upload #"..index,5);
        end
	end
end
function sessionClaim(index)	
	toast("Event Live Claim #"..index,5)
    local i = 0
    local count = 1
    local checkLogin = false
    appKill("com.ss.iphone.ugc.tiktok.lite");
    usleep(1000000);
    openURL(urlLive);
    usleep(10000000);
    if not checkLogin then
        toast("Check login #"..index,5)
        if findimg("img/check_login.png",10) then
            toast("Relogin",3)
            findimgandclick("img/bt_relogin.png",10);
            findimgandclick("img/bt_continue.png",10);
            if findimg2("img/check_suspended.png", "img/check_suspended2.png", 10) then
                
                return false
            else
                return true
            end
        else
            checkLogin = true
        end
    end
    toast("Begin claim #"..index, 3);
    i = 0
    local counterror = 0
    while i <= 0 do
        execute("rm -r /private/var/mobile/Library/AutoTouch/Scripts/Debug/*");
        if counterror > 10 then
            return true
        end
        if findimg("img/check_cleardisplay.png", 2) then
            touchDown(5, 376.68, 476.92);
            usleep(116670.42);
            touchUp(5, 376.68, 476.92);
        end
        local images = {"img/bt_claim2.png", "img/bt_claim3.png", "img/bt_claim4.png", "img/bt_claim5.png"}  
        findimgsandclick(images, 2)
        if findimg("img/check_livereward2.png",2) then            
            counterror = 0
            swipeRight()            
        else
            touchDown(5, 376.68, 476.92);
            usleep(116670.42);
            touchUp(5, 376.68, 476.92);
            counterror = counterror + 1
            usleep(2000000);
        end
        if findimgandclick("img/bt_claim_point.png",2,0.96) then
            if findimg("img/check_something.png",2,0.95) then
                toast("Something went wrong",5)
                return true
            end
            counterror = 0
            usleep(2000000);
            if not findimgandclick("img/bt_live_closepopup.png",2) then
                touchDown(3, 627.12, 1118.36);
                usleep(84717.12);
                touchUp(3, 627.12, 1118.36);
            end
            if findimg("img/bt_claim_point.png",2,0.96) then
                appKill("com.ss.iphone.ugc.tiktok.lite");
                usleep(1000000);
                openURL(urlLive);
                usleep(3000000);
            end
            if not findimg2("img/bt_watchLive.png","img/bt_watchLive2.png",3,0.95) then
                if not findimg("img/bt_complete2.png",3) then
                    appKill("com.ss.iphone.ugc.tiktok.lite");
                    usleep(1000000);
                    openURL(urlLive);
                    usleep(3000000);
                end
            end            
        end
        if findimg("img/bt_complete2.png",2) then    
            return true
        end
        toast("Check Claim #"..index, 2);
        usleep(1000000);
    end
end
function swipeRight()
    touchDown(2, 595.31, 1053.20);
    usleep(33307.21);
    touchMove(2, 577.86, 1053.20);
    usleep(16681.17);
    touchMove(2, 554.25, 1053.20);
    usleep(16717.42);
    touchMove(2, 500.87, 1053.20);
    usleep(16751.33);
    touchMove(2, 414.67, 1057.27);
    usleep(16564.58);
    touchMove(2, 319.21, 1063.38);
    usleep(16759.58);
    touchMove(2, 211.43, 1071.52);
    usleep(16519.54);
    touchMove(2, 85.19, 1087.80);
    usleep(15393.33);
    touchUp(2, 81.08, 1091.89);   
end
function autoClaim()
    appKill("com.ss.iphone.ugc.tiktok.lite");
    appKill("com.apple.mobilesafari");
    ensure_dir("/private/var/mobile/Library/AutoTouch/Scripts/sessions/");
    openURL("shadowrocket://connect");
    usleep(5000000);
    if startIndex > #fileList then
        alert("KHONG DU SESSION "..startIndex);
    else
        for i = startIndex, #fileList do
            execute("rm -r /private/var/mobile/Library/AutoTouch/Scripts/Debug/*");
            appKill("com.ss.iphone.ugc.tiktok.lite");
            appKill("com.apple.mobilesafari");
            filewrite(filestartpath, tostring(i))
            appActivate("ifakepro.settings");
            if findimg("img/check_restoredone.png", 10) then
                toast("Online",2)
            else
                touchDown(3, 0.00, 1023.99);
                usleep(2344.33);
                touchUp(3, 0.00, 1023.99);
                usleep(271047.29);
                touchDown(6, 630.20, 1207.96);
                usleep(99876.92);
                touchUp(6, 630.20, 1207.96);
                usleep(1349327.58);
                touchDown(3, 643.55, 824.12);
                usleep(132616.79);
                touchUp(3, 643.55, 824.12);
                usleep(1254895.00);
                touchDown(3, 0.00, 1109.99);
                usleep(852.25);
                touchUp(3, 0.00, 1109.99);
                usleep(212743.21);
                touchDown(1, 465.98, 413.80);
                usleep(131666.71);
                touchUp(1, 465.98, 413.80);
                usleep(3000000)
            end
            local filePath = fileList[i].name
            ensure_dir("/private/var/mobile/Library/AutoTouch/Scripts/sessions/"..filePath.."/");
            openURL("ifakepro://reconnect")
            appActivate("ifakepro.settings");
            usleep(1000000);
            touchDown(3, 709.24, 850.58);
            usleep(133469.00);
            touchUp(3, 709.24, 850.58);
            usleep(1667228.67);
            touchDown(2, 385.92, 422.96);
            usleep(115016.33);
            touchUp(2, 385.92, 422.96);
            usleep(30000000);

            toast("Restore #" .. i .. ": " .. filePath,10)
           
            openURL("ifakepro://restore?folder="..filePath)
            --if i > startIndex then
            --    usleep(5000000)
            --    if findimgandclick("img/check_restoredone.png", 2) then
             --       alert("Restore error")
             --       stop()
             --   end
            --end
            usleep(30000000)

            local startTime = os.time()
            while 1<2 do
                if findimgandclick("img/check_restoredone.png", 2) then
                    toast("Restore done",3)
                    break
                end
                if os.difftime(os.time(), startTime) > 60 then
                    toast("Hết thời gian 60 giây, dừng vòng lặp.")
                    break
                end
                usleep(2000000)  -- chờ 2 giây
            end
            usleep(2000000)
            appActivate("com.ss.iphone.ugc.tiktok.lite");
            usleep(3000000);               
            if findimg2andclick("img/bt_dont.png","img/bt_done.png", 20) then
                usleep(5000000); 
                findimg2andclick("img/bt_dont.png","img/bt_done.png", 10)
            end            
            if findimgandclick("img/bt_event.png", 10) then
                findimgandclick("img/bt_closepopup.png", 10, 0.95)
            end
            execute("rm -r /private/var/mobile/Library/AutoTouch/Scripts/Debug/*");
			if (result_dialog == 5) then
                sessionEventShare(i)                
                sessionEventUpload(i)
			else
                if (result_dialog == 6) then
                    sessionEventUpload(i)                    
                    local startTimeLiveClaim = os.time()
                    if not sessionClaim(i) then
                        toast("Remove session suspended",10)
                        openURL("ifakepro://remove?folder="..filePath)
                        usleep(5000000)
                    end
                    filewrite("/private/var/mobile/Library/AutoTouch/Scripts/sessions/"..filePath.."/time_elive.txt", tostring(os.difftime(os.time(), startTime)))
                else
                    local startTimeLiveClaim = os.time()
                    if not sessionClaim(i) then
                        toast("Remove session suspended",10)
                        openURL("ifakepro://remove?folder="..filePath)
                        usleep(5000000)
                    end
                    filewrite("/private/var/mobile/Library/AutoTouch/Scripts/sessions/"..filePath.."/time_elive.txt", tostring(os.difftime(os.time(), startTime)))
                end
			end
            execute("rm -r /private/var/mobile/Library/AutoTouch/Scripts/Debug/*");
        end     
        execute("rm -r /private/var/mobile/Library/AutoTouch/Scripts/Debug/*");
        filewrite(filestartpath, "1")
		appKill("com.ss.iphone.ugc.tiktok.lite");
        appKill("com.apple.mobilesafari");
        alert("DONE");
    end
end
traverse(path)
table.sort(fileList, function(a, b)
    return a.time > b.time
end)
--sessionEventShare(1)
autoClaim()
--sessionEventUpload(1) 
--sessionClaim(1)
