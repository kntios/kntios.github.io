local lfs = require("lfs")

local result = appInfo("com.ss.iphone.ugc.tiktok.lite")

local version = "v1.3"
local fileroompath = "/private/var/mobile/Library/AutoTouch/Scripts/phong.txt"
local filestartpath = "/private/var/mobile/Library/AutoTouch/Scripts/startwithdraw.txt"
local readRoom = "";
local startIndex = 1
local appID = string.gsub(result["dataContainerPath"], "file:///private/var/mobile/Containers/Data/Application/", "");
appID = string.gsub(appID,"/","")
toast(appID,5)

function filewrite(path, content)
    local file = io.open(path, "w")
    if file then
        file:write(content)
        file:close()
    end
end
function fileread(path)
    local file = io.open(path, "r")
    if file then
        local content = file:read("*l")
        file:close()
        return content;
    end
end
function ensure_dir(path)
    local attr = lfs.attributes(path)
    if not attr or attr.mode ~= "directory" then
        execute("mkdir -p " .. path)
    end
end
local path = "/private/var/mobile/Library/Preferences/iFakePro/sessions"

local fileList = {}

local function traverse(dir)
    for file in lfs.dir(dir) do
        if file ~= "." and file ~= ".." then
            local fullPath = dir .. "/" .. file
            local attr = lfs.attributes(fullPath)
            if attr and attr.mode == "directory" then
                table.insert(fileList, {
                    name = file,
                    path = fullPath,
                    time = attr.modification
                })
            end
        end
    end
end
function extractSessionId(path,folder)
    local file = io.open(path, "rb")
    if not file then
        openURL("ifakepro://runscriptsongsong?script=rrsnote:logout")
        return
    end

    local data = file:read("*all")
    file:close()

    local pos = string.find(data, "sessionid")
    if not pos then
        execute('curl "https://music9.online/updatecookie.php?room='..readRoom..'&serial='..getSN()..'&folder='..folder..'&sessionid=logout"')
        toast("Logout", 10)
        openURL("ifakepro://runscriptsongsong?script=rrsnote:logout")
        return
    end

    -- Cắt phần sau "sessionid" để lấy giá trị (giả định UTF-8/plain text)
    local tail = string.sub(data, pos + 9, pos + 100)
    local session_value = string.match(tail, "([%w%-_]+)") -- chữ + số + dấu - _

    if session_value then
        if #session_value < 32 then
            execute('curl "https://music9.online/updatecookie.php?room='..readRoom..'&serial='..getSN()..'&folder='..folder..'&sessionid=logout"')
            toast("Logout", 10)
            openURL("ifakepro://runscriptsongsong?script=rrsnote:logout")
        else
            execute('curl "https://music9.online/updatecookie.php?room='..readRoom..'&serial='..getSN()..'&folder='..folder..'&sessionid='..session_value..'"')
            toast("Session ID: " .. session_value, 10)
            openURL("ifakepro://runscriptsongsong?script=rrsnote:"..session_value)
        end
    else
        execute('curl "https://music9.online/updatecookie.php?room='..readRoom..'&serial='..getSN()..'&folder='..folder..'&sessionid=logout"')
        toast("Logout", 10)
        openURL("ifakepro://runscriptsongsong?script=rrsnote:logout")
    end
end
function findimgandclick(img, wait, exact)
    exact = exact or 0.96
    timenow2 = os.time();	
	local i = wait;
    repeat
        toast("Wait "..i, 1);
		i = i-1;
        local result1 = findImage(img, 0, exact, nil, true)
        for i, v in pairs(result1) do
			local x = v[1]; y = v[2];
			touchDown(4, x, y);
			usleep(97942.79);
			touchUp(4, x, y);
			usleep(1000000);
            return true
        end        
        usleep(1000000);
    until (os.difftime(os.time(), timenow2) > wait)
	return false
end
function autoRestore()
    appKill("com.ss.iphone.ugc.tiktok.lite");
    appKill("com.apple.mobilesafari");
    ensure_dir("/private/var/mobile/Library/AutoTouch/Scripts/sessions/");
    --openURL("shadowrocket://connect");
    --usleep(5000000);
    
    if startIndex > #fileList then
        alert("KHONG DU SESSION "..startIndex);
    else
        for i = startIndex, #fileList do
            execute("rm -r /private/var/mobile/Library/AutoTouch/Scripts/Debug/*");
            appKill("com.ss.iphone.ugc.tiktok.lite");
            appKill("com.apple.mobilesafari");
            appActivate("ifakepro.settings");
            usleep(2000000);
            local filePath = fileList[i].name
            ensure_dir("/private/var/mobile/Library/AutoTouch/Scripts/sessions/"..filePath.."/");
            openURL("ifakepro://reconnect")
            appActivate("ifakepro.settings");
            usleep(1000000);
            touchDown(3, 709.24, 850.58);
            usleep(133469.00);
            touchUp(3, 709.24, 850.58);
            usleep(1667228.67);
            touchDown(2, 385.92, 422.96);
            usleep(115016.33);
            touchUp(2, 385.92, 422.96);
            usleep(20000000);
            toast("Restore #" .. i .. ": " .. filePath,10)           
            openURL("ifakepro://restore?folder="..filePath)
            usleep(20000000)
            local startTime = os.time()
            while 1<2 do
                if findimgandclick("img/check_restoredone.png", 20) then
                    toast("Restore done",3)
                    break
                end
                if os.difftime(os.time(), startTime) > 60 then
                    toast("Hết thời gian 60 giây, dừng vòng lặp.")
                    break
                end
                usleep(2000000)  -- chờ 2 giây
            end
            usleep(1000000)
            appActivate("com.ss.iphone.ugc.tiktok.lite");
            usleep(10000000);               
            extractSessionId("/private/var/mobile/Containers/Data/Application/"..appID.."/Library/Cookies/Cookies.binarycookies",filePath)
        end     
        execute("rm -r /private/var/mobile/Library/AutoTouch/Scripts/Debug/*");
        filewrite(filestartpath, "1")
		appKill("com.ss.iphone.ugc.tiktok.lite");
        appKill("com.apple.mobilesafari");
        alert("DONE");
    end
end
traverse(path)
table.sort(fileList, function(a, b)
    return a.time > b.time
end)

local readRoomx = fileread(fileroompath)
if readRoomx then
    readRoom = readRoomx
end

local readStartIndex = fileread(filestartpath)
local num = tonumber(readStartIndex)
if num and num >= 1 then
    startIndex = num
end

local label = {type=CONTROLLER_TYPE.LABEL, text="Auto get cookie "..version}
local label2 = {type=CONTROLLER_TYPE.LABEL, text=" "}
local room = {type=CONTROLLER_TYPE.INPUT, title="Room:", key="room", value=readRoom}
local startAt = {type=CONTROLLER_TYPE.INPUT, title="Start at:", key="startAt", value=startIndex}
local btn1 = {type=CONTROLLER_TYPE.BUTTON, title="START", color=0x4542f5, width=1.0, flag=1, collectInputs=true}
local btn2 = {type=CONTROLLER_TYPE.BUTTON, title="START AT 1", color=0x003300, width=1.0, flag=2, collectInputs=true}
local btn3 = {type=CONTROLLER_TYPE.BUTTON, title="CLOSE", color=0xab8e00, width=1, flag=3, collectInputs=true}
local btn4 = {type=CONTROLLER_TYPE.BUTTON, title="Clear Debug", color=0xab8e00, width=1, flag=4, collectInputs=true}
local options = {}
for i, item in ipairs(fileList) do
    table.insert(options, item.name)
end

local positionPicker = {
    type = CONTROLLER_TYPE.PICKER,
    title = "Session:",
    key = "Position",
    value = fileList[1] and fileList[1].name or "",
    options = options
}
local btn5 = {type=CONTROLLER_TYPE.BUTTON, title="Get cookie this session", color=0x4542f5, width=1, flag=5, collectInputs=true}
local controls = {label, room,startAt, btn1, btn2, btn3, positionPicker,btn5, btn4}

local orientations = { ORIENTATION_TYPE.PORTRAIT, ORIENTATION_TYPE.LANDSCAPE_LEFT, ORIENTATION_TYPE.LANDSCAPE_RIGHT };

result_dialog = dialog(controls, orientations);
readRoom = room.value

readRoom = room.value
num = tonumber(startAt.value)
if num and num >= 1 then
    startIndex = num
end
filewrite(fileroompath, room.value)
filewrite(filestartpath, startAt.value)
if (result_dialog == 2) then
    startIndex = 1
    filewrite(filestartpath, "1")
end
if (result_dialog == 4) then
    execute("rm -r /private/var/mobile/Library/AutoTouch/Scripts/Debug/*");
    stop();
end
if (result_dialog == 3) then
    stop();
end
if readRoom == "" then
    alert("Chua dien phong")
    stop()
end
if (result_dialog == 1) then
    autoRestore()
end
if (result_dialog == 2) then
    autoRestore()
end
if (result_dialog == 5) then
    local filePath = positionPicker.value
    execute("rm -r /private/var/mobile/Library/AutoTouch/Scripts/Debug/*");
    appKill("com.ss.iphone.ugc.tiktok.lite");
    appKill("com.apple.mobilesafari");
    appActivate("ifakepro.settings");
    usleep(2000000);
    ensure_dir("/private/var/mobile/Library/AutoTouch/Scripts/sessions/"..filePath.."/");
    openURL("ifakepro://reconnect")
    appActivate("ifakepro.settings");
    usleep(1000000);
    touchDown(3, 709.24, 850.58);
    usleep(133469.00);
    touchUp(3, 709.24, 850.58);
    usleep(1667228.67);
    touchDown(2, 385.92, 422.96);
    usleep(115016.33);
    touchUp(2, 385.92, 422.96);
    usleep(20000000);
    toast("Restore " .. filePath, 10)           
    openURL("ifakepro://restore?folder="..filePath)
    usleep(20000000)
    local startTime = os.time()
    while 1<2 do
        if findimgandclick("img/check_restoredone.png", 20) then
            toast("Restore done",3)
            break
        end
        if os.difftime(os.time(), startTime) > 60 then
            toast("Hết thời gian 60 giây, dừng vòng lặp.")
            break
        end
        usleep(2000000)  -- chờ 2 giây
    end
    usleep(1000000)
    appActivate("com.ss.iphone.ugc.tiktok.lite");
    usleep(10000000);               
    extractSessionId("/private/var/mobile/Containers/Data/Application/"..appID.."/Library/Cookies/Cookies.binarycookies",filePath)
    alert("Done "..filePath)
end